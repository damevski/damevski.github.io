package edu.utah.sci.ccainvokeportmethod;

import gov.cca.*;

import java.lang.reflect.*;

import ptolemy.actor.AtomicActor;
import ptolemy.actor.TypedAtomicActor;
import ptolemy.actor.TypedIOPort;

import ptolemy.actor.parameters.PortParameter;
import ptolemy.data.BooleanToken;
import ptolemy.data.IntToken;
import ptolemy.data.StringToken;
import ptolemy.data.expr.FileParameter;
import ptolemy.data.expr.Parameter;
import ptolemy.data.type.BaseType;

import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.util.Workspace;
import ptolemy.kernel.util.Attribute;

import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;

public class CCAInvokePortMethodActor extends TypedAtomicActor {

  public CCAInvokePortMethodActor(CompositeEntity container, java.lang.String name)
    throws IllegalActionException, NameDuplicationException {
    super(container, name);

    System.out.println("CCAInvokePortMethodActor(CompositeEntity container, java.lang.String name)");

    frameworkURL = new PortParameter(this, "frameworkURL",
				     new StringToken("http://..."));
    new Parameter(frameworkURL.getPort(), "_showName", BooleanToken.TRUE);

    componentName = new PortParameter(this, "componentName",
				      new StringToken("c1"));
    new Parameter(componentName.getPort(), "_showName", BooleanToken.TRUE);

    portName = new PortParameter(this, "portName",
				 new StringToken("z"));
    new Parameter(portName.getPort(), "_showName", BooleanToken.TRUE);

    portType = new PortParameter(this, "portType",
				 new StringToken("x.y.z"));
    new Parameter(portType.getPort(), "_showName", BooleanToken.TRUE);

    methodName = new PortParameter(this, "methodName",
				   new StringToken("m1"));
    new Parameter(methodName.getPort(), "_showName", BooleanToken.TRUE);

    log = new TypedIOPort(this, "log", false, true);
    log.setTypeEquals(BaseType.STRING);
    new Parameter(log, "_showName", BooleanToken.TRUE);
  
    _attachText(
		"_iconDescription",
		"<svg>\n"
		+ "<rect x=\"0\" y=\"0\" "
		+ "width=\"75\" height=\"50\" style=\"fill:blue\"/>\n"
		+ "<text x=\"5\" y=\"30\""
		+ "style=\"font-size:14; fill:yellow; font-family:SansSerif\">"
		+ "CCAInvokePortMethod</text>\n"
		+ "</svg>\n");
  }

  public void fire() throws IllegalActionException {
    super.fire();

    try {
	System.out.println("start");

	frameworkURL.update();
	StringToken fu = (StringToken) frameworkURL.getToken();
        String url = fu.stringValue();
	System.out.println("url = " + url + ";");

	componentName.update();
	StringToken cn = (StringToken) componentName.getToken();
        String componentname = cn.stringValue();

	portName.update();
	StringToken pn = (StringToken) portName.getToken();
        String portname = pn.stringValue();

	portType.update();
	StringToken pt = (StringToken) portType.getToken();
        String porttype = pt.stringValue();

	methodName.update();
	StringToken mn = (StringToken) methodName.getToken();
        String methodname = mn.stringValue();

	sidlx.rmi.SimpleOrb echo = (sidlx.rmi.SimpleOrb) new sidlx.rmi.SimpleOrb();
	long tid = orbStart(echo,portNumber);

	gov.llnl.sidl.BaseClass base = gov.cca.AbstractFramework.Wrapper._connect(url);
	gov.cca.AbstractFramework fwk = (gov.cca.AbstractFramework) (gov.cca.AbstractFramework.Wrapper._cast(base));

	gov.cca.TypeMap mainProperties = fwk.createTypeMap();
	gov.cca.Services mainServices = fwk.getServices("ccainvportmethod", "main", mainProperties);
	mainServices.registerUsesPort("invokeBuilder", "cca.BuilderService", mainServices.createTypeMap());
	gov.cca.Port bsp = mainServices.getPort("invokeBuilder");

	String builderUrl = bsp._getURL();
	gov.llnl.sidl.BaseClass baseBuilder = gov.cca.ports.BuilderService.Wrapper._connect(builderUrl);
	gov.cca.ports.BuilderService bs = 
	    (gov.cca.ports.BuilderService) 
	    (gov.cca.ports.BuilderService.Wrapper._cast(baseBuilder));

	mainServices.registerUsesPort("cipm-uses", porttype, mainServices.createTypeMap()); 
	gov.cca.ComponentID port_cid = bs.getComponentID(componentname);
	System.out.println("here0");
	bs.connect(mainServices.getComponentID(),"cipm-uses",port_cid,portname); 
	System.out.println("here1");

	gov.cca.Port port = mainServices.getPort("cipm-uses");
        String portUrl = port._getURL();
	Class klas = Class.forName(porttype + "$Wrapper");
       
	// gov.llnl.sidl.BaseClass basePort = PORTCLASS.Wrapper._connect(portUrl);
	Class [] connParamClasses = new Class [1];
	connParamClasses[0] = portUrl.getClass();
	Method conn = klas.getMethod("_connect",connParamClasses);
	Object [] connParams = new Object [1];
	connParams[0] = portUrl;
	Object connret = conn.invoke(klas,connParams);
	gov.llnl.sidl.BaseClass basePort = (gov.llnl.sidl.BaseClass)(connret);
	System.out.println("here2 " + basePort.getClass().getName());
	
	// ... PORTCLASS.Wrapper._cast(basePort)
	Class [] castParamClasses = new Class [1];
	castParamClasses[0] = gov.llnl.sidl.BaseClass.class;
	Method cast = klas.getMethod("_cast",castParamClasses);
	Object [] castParams = new Object [1];
	castParams[0] = basePort;
	Object castret = cast.invoke(klas,castParams);
	System.out.println("here3");	
	
	// PORTINSTANCE.methodname()
	Method [] metodi = castret.getClass().getMethods();
	for(int i=0; i < metodi.length; i++) {
	    System.out.println(metodi[i].getName() + " == " + methodname);
	    System.out.println(metodi[i].getName().compareTo(methodname) == 0);
	    if(metodi[i].getName().compareTo(methodname) == 0) {
		//No arguments to method for now
		metodi[i].invoke(castret,new Object[0]);
	    }
        }
	
	log.send(0, new StringToken("done"));
	return;
    } catch (NoSuchMethodException mex) {
	System.out.println("Cannot find port in this context");
	System.out.println("Message = " + mex.getMessage());
	log.send(0, new StringToken("error"));
	return;
    } catch (ClassNotFoundException cex) {
	System.out.println("Cannot find port in this context");
	System.out.println("Message = " + cex.getMessage());
	log.send(0, new StringToken("error"));
	return;
    } catch (gov.cca.CCAException.Wrapper e) {
	System.out.println("CCAException caught: " + e.getNote());
	log.send(0, new StringToken(""));
	return;
    } catch (Exception e) {
	if (((sidl.BaseInterface)e).isType("sidl.SIDLException")) {
	    System.err.println("Unexpected SIDL Exception thrown");
	} else {
	    System.err.println("Unexpected and unknown exception thrown");
	    System.out.println("Message = " + e.getMessage());
	}
	log.send(0, new StringToken(""));
	return;
    }
  }

  private long orbStart(sidlx.rmi.SimpleOrb echo, int port_number) {
    sidl.rmi.ProtocolFactory pf = new sidl.rmi.ProtocolFactory();
    if(!pf.addProtocol("simhandle","sidlx.rmi.SimHandle")) {
      System.out.println("Error in addProtocol");
      return -1;
    }
	
    echo.requestPort(port_number);
    long tid = echo.run();
    sidl.rmi.ServerRegistry.registerServer(echo);
    return tid;
  }

    /** URL is part of Babel RMI, and it references 
     *  the framework we are conecting to. 
     */
    public PortParameter frameworkURL;

    /** The name of the component that has the 'provides'
     *   port
     */
    public PortParameter componentName;

    /** The name of the port registered as 'provides' in 
     *  the framework.
     */
    public PortParameter portName;

    /** The type of the port registered as 'provides' in 
     *  the framework.
     */
    public PortParameter portType;

    /** The name of the method we are to invoke on the 
     *  specified port.
     */
    public PortParameter methodName;
    
    /** A log of the components that were created and
     *  connections made.
     */
    public TypedIOPort log;

    /**
     *  Default ORB port number
     */
    final public static int portNumber = 23233;
}
