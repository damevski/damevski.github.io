package edu.utah.sci.ccaeventlistener;

import gov.cca.*;

import ptolemy.actor.AtomicActor;
import ptolemy.actor.TypedAtomicActor;
import ptolemy.actor.TypedIOPort;

import ptolemy.actor.parameters.PortParameter;
import ptolemy.data.BooleanToken;
import ptolemy.data.IntToken;
import ptolemy.data.StringToken;
import ptolemy.data.expr.FileParameter;
import ptolemy.data.expr.Parameter;
import ptolemy.data.type.BaseType;

import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.util.Workspace;
import ptolemy.kernel.util.Attribute;

import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;

public class CCAEventListenerActor extends TypedAtomicActor {

  public CCAEventListenerActor(CompositeEntity container, java.lang.String name)
    throws IllegalActionException, NameDuplicationException {
    super(container, name);

    System.out.println("CCAEventListenerActor(CompositeEntity container, java.lang.String name)");

    frameworkURL = new PortParameter(this, "frameworkURL",
				     new StringToken("http://..."));
    new Parameter(frameworkURL.getPort(), "_showName", BooleanToken.TRUE);

    subscription = new PortParameter(this, "subscription",
				     new StringToken("x.y.z"));
    new Parameter(subscription.getPort(), "_showName", BooleanToken.TRUE);

    log = new TypedIOPort(this, "log", false, true);
    log.setTypeEquals(BaseType.STRING);
    new Parameter(log, "_showName", BooleanToken.TRUE);

    _attachText(
		"_iconDescription",
		"<svg>\n"
		+ "<rect x=\"0\" y=\"0\" "
		+ "width=\"75\" height=\"50\" style=\"fill:blue\"/>\n"
		+ "<text x=\"5\" y=\"30\""
		+ "style=\"font-size:14; fill:yellow; font-family:SansSerif\">"
		+ "CCAEventListenerActor</text>\n"
		+ "</svg>\n");
  }

  public void fire() throws IllegalActionException {
    super.fire();

    try {
	System.out.println("start");
	frameworkURL.update();
	StringToken fu = (StringToken) frameworkURL.getToken();
        String url = fu.stringValue();

	subscription.update();
	StringToken sb = (StringToken) subscription.getToken();
        String subname = sb.stringValue();

	sidlx.rmi.SimpleOrb echo = (sidlx.rmi.SimpleOrb) new sidlx.rmi.SimpleOrb();
	long tid = orbStart(echo,portNumber);

	gov.llnl.sidl.BaseClass base = gov.cca.AbstractFramework.Wrapper._connect(url);
	gov.cca.AbstractFramework fwk = (gov.cca.AbstractFramework) (gov.cca.AbstractFramework.Wrapper._cast(base));

	gov.cca.TypeMap mainProperties = fwk.createTypeMap();
	gov.cca.Services mainServices = fwk.getServices("ccaeventlistener", "main", mainProperties);
	mainServices.registerUsesPort("cela_es", "cca.EventService", mainServices.createTypeMap());
	System.out.println("here");
	gov.cca.Port es_port = mainServices.getPort("cela_es");

	String esUrl = es_port._getURL();
	//change sci.cca to gov.cca once event service gets into cca spec
	gov.llnl.sidl.BaseClass baseES = sci.cca.ports.SubscriberEventService.Wrapper._connect(esUrl);
	sci.cca.ports.SubscriberEventService es = 
	    (sci.cca.ports.SubscriberEventService) 
	    (sci.cca.ports.SubscriberEventService.Wrapper._cast(baseES));

	System.out.println("here1");

	sci.kepler.EventListener kel = new sci.kepler.EventListener();
	sci.cca.Subscription sub = es.getSubscription(subname);
	sub.registerEventListener("cela",kel);

	System.out.println("here2");


	System.out.println("here3");
	log.send(0, new StringToken("done"));
	return;

    } catch (gov.cca.CCAException.Wrapper e) {
	System.out.println("CCAException caught: " + e.getNote());
	log.send(0, new StringToken(""));
	return;
    } catch (Exception e) {
	if (((sidl.BaseInterface)e).isType("sidl.SIDLException")) {
	    System.err.println("Unexpected SIDL Exception thrown");
	} else {
	    System.err.println("Unexpected and unknown exception thrown");
	}
	log.send(0, new StringToken(""));
	return;
    }
  }

  private long orbStart(sidlx.rmi.SimpleOrb echo, int port_number) {
    sidl.rmi.ProtocolFactory pf = new sidl.rmi.ProtocolFactory();
    if(!pf.addProtocol("simhandle","sidlx.rmi.SimHandle")) {
      System.out.println("Error in addProtocol");
      return -1;
    }
	
    echo.requestPort(port_number);
    long tid = echo.run();
    sidl.rmi.ServerRegistry.registerServer(echo);
    return tid;
  }

    /** URL is part of Babel RMI, and it references 
     *  the framework we are conecting to. 
     */
    public PortParameter frameworkURL;
    
    /** The subscription represents one or more event
     *  channels that we are going to listen to 
     */
    public PortParameter subscription;

    /** A log of the components that were created and
     *  connections made.
     */
    public TypedIOPort log;

    /**
     *  Default ORB port number
     */
    final public static int portNumber = 23233;
}
