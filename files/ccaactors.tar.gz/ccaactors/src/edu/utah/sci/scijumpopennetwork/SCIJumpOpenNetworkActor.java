package edu.utah.sci.scijumpopennetwork;

import gov.cca.*;
import sci.cca.*;

import ptolemy.actor.AtomicActor;
import ptolemy.actor.TypedAtomicActor;
import ptolemy.actor.TypedIOPort;

import ptolemy.actor.parameters.PortParameter;
import ptolemy.data.BooleanToken;
import ptolemy.data.IntToken;
import ptolemy.data.StringToken;
import ptolemy.data.expr.FileParameter;
import ptolemy.data.expr.Parameter;
import ptolemy.data.type.BaseType;

import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.util.Workspace;
import ptolemy.kernel.util.Attribute;

import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;

public class SCIJumpOpenNetworkActor extends TypedAtomicActor {

  public SCIJumpOpenNetworkActor(CompositeEntity container, java.lang.String name)
    throws IllegalActionException, NameDuplicationException {
    super(container, name);

    System.out.println("SCIJumpOpenNetworkActor(CompositeEntity container, java.lang.String name)");

    frameworkURL = new PortParameter(this, "frameworkURL",
				     new StringToken("http://..."));
    new Parameter(frameworkURL.getPort(), "_showName", BooleanToken.TRUE);

    log = new TypedIOPort(this, "log", false, true);
    log.setTypeEquals(BaseType.STRING);
    new Parameter(log, "_showName", BooleanToken.TRUE);

    outURL = new TypedIOPort(this, "outURL", false, true);
    outURL.setTypeEquals(BaseType.STRING);
    new Parameter(outURL, "_showName", BooleanToken.TRUE);

    _attachText(
		"_iconDescription",
		"<svg>\n"
		+ "<rect x=\"0\" y=\"0\" "
		+ "width=\"75\" height=\"50\" style=\"fill:blue\"/>\n"
		+ "<text x=\"5\" y=\"30\""
		+ "style=\"font-size:14; fill:yellow; font-family:SansSerif\">"
		+ "SCIJumpOpenNetwork</text>\n"
		+ "</svg>\n");
  }

  public void fire() throws IllegalActionException {
    super.fire();

    try {
	System.out.println("start");
	frameworkURL.update();
	StringToken fu = (StringToken) frameworkURL.getToken();
        String url = fu.stringValue();

	System.out.println("url = " + url + ";");

	sidlx.rmi.SimpleOrb echo = (sidlx.rmi.SimpleOrb) new sidlx.rmi.SimpleOrb();
	long tid = orbStart(echo,portNumber);

	gov.llnl.sidl.BaseClass base = sci.cca.AbstractFramework.Wrapper._connect(url);
	sci.cca.AbstractFramework fwk = (sci.cca.AbstractFramework) (sci.cca.AbstractFramework.Wrapper._cast(base));

	gov.cca.TypeMap mainProperties = fwk.createTypeMap();
	gov.cca.Services mainServices = fwk.getServices("scijumpopennetwork", "main", mainProperties);
	mainServices.registerUsesPort("son_als", "cca.ApplicationLoaderService", mainServices.createTypeMap());
	System.out.println("here");
	gov.cca.Port als_port = mainServices.getPort("son_als");

	String loaderUrl = als_port._getURL();
	gov.llnl.sidl.BaseClass baseLoader = sci.cca.ports.ApplicationLoaderService.Wrapper._connect(loaderUrl);
	sci.cca.ports.ApplicationLoaderService als = 
	    (sci.cca.ports.ApplicationLoaderService) 
	    (sci.cca.ports.ApplicationLoaderService.Wrapper._cast(baseLoader));

	System.out.println("here1");
	gov.cca.ComponentID.Array1.Holder cidList = new gov.cca.ComponentID.Array1.Holder();
	gov.cca.ConnectionID.Array1.Holder connList = new gov.cca.ConnectionID.Array1.Holder();
	System.out.println("here2");
	try {
	    als.loadFile("tutorial.net",cidList,connList);
	} catch (Exception e) { }

	System.out.println("here3");
	log.send(0, new StringToken("done"));
	outURL.send(0, fu);
	return;

    } catch (gov.cca.CCAException.Wrapper e) {
	System.out.println("CCAException caught: " + e.getNote());
	log.send(0, new StringToken(""));
	return;
    } catch (Exception e) {
	if (((sidl.BaseInterface)e).isType("sidl.SIDLException")) {
	    System.err.println("Unexpected SIDL Exception thrown");
	} else {
	    System.err.println("Unexpected and unknown exception thrown");
	}
	log.send(0, new StringToken(""));
	return;
    }
  }

  private long orbStart(sidlx.rmi.SimpleOrb echo, int port_number) {
    sidl.rmi.ProtocolFactory pf = new sidl.rmi.ProtocolFactory();
    if(!pf.addProtocol("simhandle","sidlx.rmi.SimHandle")) {
      System.out.println("Error in addProtocol");
      return -1;
    }
	
    echo.requestPort(port_number);
    long tid = echo.run();
    sidl.rmi.ServerRegistry.registerServer(echo);
    return tid;
  }

    /** URL is part of Babel RMI, and it references 
     *  the framework we are conecting to. 
     */
    public PortParameter frameworkURL;
    
    /** A log of the components that were created and
     *  connections made.
     */
    public TypedIOPort log;

    public TypedIOPort outURL;

    /**
     *  Default ORB port number
     */
    final public static int portNumber = 23233;
}
